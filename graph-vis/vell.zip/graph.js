"use strict"

function arrayBufferToString(buffer){
    var arr = new Uint8Array(buffer);
    var str = String.fromCharCode.apply(String, arr);
    return str;
}


//Preparo una funcis per descarregar les dades JSON assincronament
//Extreta de: http://stackoverflow.com/questions/9838812/how-can-i-open-a-json-file-in-javascript-without-jquery
function loadJSON(path, success, error, extra_param)
{
var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function()
	{
        if (xhr.readyState === XMLHttpRequest.DONE) 
		{
	       	if (xhr.status === 200) 
			{
            	if (success)
				{
					var data;
					try {
						data = JSON.parse(xhr.responseText);
					} 
					catch (e) {
		                		if (error)
							return error("JSON file: \""+ path + "\". " + e);
					}
					success(data, extra_param);
				}
			} 
			else 
			{
                if (error)
				{
					var s=null;
					if (xhr.response)
					{
						var s=arrayBufferToString(xhr.response);
						if (-1!=s.indexOf("<body>"))
							s=s.substring(s.indexOf("<body>"));
					}
		    			error("JSON file: \""+ path + "\". Status: " + xhr.statusText + "\n\nURL: "+ path + ((xhr.getAllResponseHeaders && xhr.getAllResponseHeaders()) ? "\n\nResponse headers:\n"+xhr.getAllResponseHeaders() : "") + ((s) ? "\nResponse Body:\n"+s : ""), extra_param);
				}
			}
		}
	};
	xhr.open("GET", path, true);
	//xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded; charset=ISO-8859-1');
	xhr.setRequestHeader('Accept', 'application/json');
	//xhr.setRequestHeader('Accept-Charset', 'utf-8');	Aixr no li agrada als navegadors, donen error
	xhr.send();
}

/*
 * Binary search (bsearch) in a sorted array (from https://oli.me.uk/2013/06/08/searching-javascript-arrays-with-a-binary-search   http://jsfiddle.net/aryzhov/pkfst550/
 * Returns 
      * the index of the element in a sorted array that is iqual to 'elem' (see the note if there are more than one)
      * (-n-1) where n is the insertion point for the new element.  E.g. -5 means "insert in i=4" to keep the array sorted, a.k.a "insert between 3 and 4".
 * Parameters:
 *     list - The array
 *     elem - An element to search for
 *     compare_fn - A comparator function in the same way that Array.sort() wants it: The function takes two arguments: (elem, b) and returns:
 *        a negative number  if a is less than b;
 *        0 if a is equal to b;
 *        a positive number of a is greater than b.
 * Note: The array may contain duplicate elements. 
 * If there are more than one equal elements in the array, the returned value can be the index of any one of the equal elements.
 */
function binarySearch(list, elem, compare_fn)
{
	var m = 0;
	var n = list.length - 1;
	while (m <= n) {
        	var k = (n + m) >> 1;
	        var cmp = compare_fn(elem, list[k]);
	        if (cmp > 0) {
			m = k + 1;
	        } else if(cmp < 0) {
			n = k - 1;
		} else {
			return k;
		}
	}
	return -m - 1;
}


function removeAbbrNamespace(s)
{
    var i=s.indexOf(':');
    if (i!=-1)
        return s.substring(i+1, s.length);
    return s;
}



function IniciaGraph(div_name, graph_json)
{
	loadJSON(graph_json,
			IniciaDibuixGraph,
			function(xhr) { alert(xhr); },
			{div_name:div_name, graph_json:graph_json});
}

function IsNodeTypeOfNetwork(nod, qnode)
{
	if (nod.supertype && qnode.supertype)
	{
		for (var i=0; i<qnode.supertype.length; i++)
			if (nod.supertype==qnode.supertype[i])
				return true;
	}
	if (nod.type && qnode.type)
	{
		for (var i=0; i<qnode.type.length; i++)
			if (nod.type==qnode.type[i])
				return true;
	}
	if (nod.subtype && qnode.subtype)
	{
		for (var i=0; i<qnode.subtype.length; i++)
			if (nod.subtype==qnode.subtype[i])
				return true;
	}
	return false;
}

function INodFromNetworkId(d, id)
{
	var i=binarySearch(d.sortedNodId, id, findSortedNodId);
	if (i<0 || i>d.sortedNodId.length)
		return -1;
	return d.sortedNodId[i].i;
}

function LoopIntoLinksOfNetwork(d, nod, filter, path)
{
	for (var propName in nod.links) 
	{
		if (propName=="source")
			continue;		
		var links=nod.links[propName];
		for (var i_link=0; i_link<links.length; i_link++)
		{
			var i=INodFromNetworkId(d, links[i_link])
			if (i<0)
			{
				alert("The linked resource " + links[i_link] + " in links." + propName + " of the node network " + nod.id +" cannot be found as a node network id in the network.");
				return;
			}
			var new_nod=d.network[i];
			
			//Si arribo al final plego i dic que l'he trobat
			if (IsNodeTypeOfNetwork(new_nod, filter.end_node))
			{
				path[path.length-1].push(i);
				path.push(path[path.length-1].slice(0)); //Si ha trobat el final duplico el path i el guardo.
				continue;
			}
			
			//Si is un node prohibit el salto
			if (IsNodeTypeOfNetwork(new_nod, filter.excluded_intermediate_node))
				continue;
			//si arribo a in node ini el salto
			if (IsNodeTypeOfNetwork(new_nod, filter.ini_node))
				continue;
			
			path[path.length-1].push(i);
			LoopIntoLinksOfNetwork(d, new_nod, filter, path)
			path[path.length-1].pop();
		}
	}
	return false;
}

function ApplyFilterNetwork(d, filter, selected_nodes)
{
var network=d.network;

	//comengo per un node.
	for (var i=0; i<network.length; i++)
	{
		var nod=network[i];
		//miro si el node is un extrem
		if (IsNodeTypeOfNetwork(nod, filter.ini_node))
		{
			var path=[[i]];
			LoopIntoLinksOfNetwork(d, nod, filter, path);
			path.pop();
			for (var j=0; j<path.length; j++)
			{
				if (filter.type=="extreme")
				{
					selected_nodes[path[j][0]]=true;
					selected_nodes[path[j][path[j].length-1]]=true;
				}	
				else
				{
					for (var p=0; p<path[j].length; p++)
						selected_nodes[path[j][p]]=true;
				}
			}
		}
	}
}


function sortSortedNodId(a, b)
{
	return ((a.id < b.id) ? -1 : ((a.id > b.id) ? 1 : 0));
}

function findSortedNodId(id, b)
{
	return ((id < b.id) ? -1 : ((id > b.id) ? 1 : 0));
}

function sortSortedType(a, b)
{
	return ((a.type < b.type) ? -1 : ((a.type > b.type) ? 1 : 0));
}

function findSortedType(type, b)
{
	return ((type < b.type) ? -1 : ((type > b.type) ? 1 : 0));
}

function AddQSearchInfoNetwork(d)
{
	d.sortedNodId=[];
	for (var i=0; i<d.network.length; i++)
	{
		d.sortedNodId[i]={id: d.network[i].id, i: i};
	}	
	d.sortedNodId.sort(sortSortedNodId);
}

function TransformaNetworkEnVisData(nodes, edges, d, styles, selected_nodes, select_true)
{
var network=d.network;

	styles.node.sort(sortSortedType);
	for (var i=0; i<network.length; i++)
	{
		if (    (select_true && !selected_nodes[i]) ||
			(!select_true && selected_nodes[i])   )
			continue;

		var nod=network[i];
		var i_style=binarySearch(styles.node, nod.type, findSortedType);
		if (i_style<0 || i_style>d.sortedNodId.length)
			nodes.push({id: nod.id, label: removeAbbrNamespace(nod.id), color: {background:'LightYellow', border:'GoldenRod'}, borderWidth: 3});
		else
		{
			var style=styles.node[i_style];
			nodes.push({id: nod.id, label: removeAbbrNamespace(nod.id), shape: (style.shape ? style.shape : 'box'), color: (style.color ? style.color : {background:'LightYellow', border:'GoldenRod'}), borderWidth: (style.borderWidth ? style.borderWidth : 1)});
		}
		for (var propName in nod.links) 
		{
			if (propName=="source")
				continue;		
			var links=nod.links[propName];
			for (var i_link=0; i_link<links.length; i_link++)
			{				
				var j=INodFromNetworkId(d, links[i_link]);
				if (    (select_true && !selected_nodes[j]) ||
					(!select_true && selected_nodes[j])   )
					continue;
			        edges.push({from: nod.id, to: links[i_link], arrows:'to', label: propName, font: {align: 'top', size: 10}});
			}
		}
	}
}

function IniciaDibuixGraph(d, param)
{
    // initialize your network!
	var nodes=[], edges=[], selected_nodes=[];

	AddQSearchInfoNetwork(d);

	//Connecta un SDG indicator amb una EONetwork sense passar per un SDG
	var filter={
		type: "connected",  //De moment pot valer "connected" o "extreme"
		connect: true,
		ini_node: {type: ["EOV"], supertype: null, subtype: null},
		excluded_intermediate_node: {supertype: null, type: ["SDG"], subtype: null},
		end_node: {supertype: null, type: ["EONetwork"], subtype: null},
	}

	//Useful table of colors: https://www.w3schools.com/colors/colors_names.asp
	var styles={
		node: [{
			type: "EONetwork",
			shape: 'box',
			color: {background:'Aquamarine', border:'Blue'},
			borderWidth: 3
		},{
			type: "SDG",
			shape: 'box',
			color: {background:'LightYellow', border:'GoldenRod'},
			borderWidth: 3
		},{
			type: "SDGIndicator_S",
			shape: 'box',
			color: {background:'MediumSlateBlue', border:'Indigo'},
			borderWidth: 3
		},{
			type: "SDGIndicator_I",
			shape: 'box',
			color: {background:'OrangeRed', border:'Red'},
			borderWidth: 3
		},{
			type: "SDGIndicator_R",
			shape: 'box',
			color: {background:'RoyalBlue', border:'Blue'},
			borderWidth: 3
		},{
			type: "SDGIndicator_P",
			shape: 'box',
			color: {background:'SandyBrown', border:'Brown'},
			borderWidth: 3
		},{
			type: "EBV",
			shape: 'box',
			color: {background:'YellowGreen', border:'SeaGreen'},
			borderWidth: 3
		},{
			type: "ECV",
			shape: 'box',
			color: {background:'Pink', border:'Orchid'},
			borderWidth: 3
		},{
			type: "EOV",
			shape: 'box',
			color: {background:'Silver', border:'DarkGray'},
			borderWidth: 3
		},{
			type: "SocioEcoV",
			shape: 'box',
			color: {background:'Orchid', border:'MediumVioletRed'},
			borderWidth: 3
		},{
			type: "EAV",
			shape: 'box',
			color: {background:'LightBlue', border:'LightSteelBlue'},
			borderWidth: 3
		},{
			type: "EREV",
			shape: 'box',
			color: {background:'Moccasin', border:'Khaki'},
			borderWidth: 3
		}],
		eage: []  //no programat encara
	}
	ApplyFilterNetwork(d, filter, selected_nodes);

	TransformaNetworkEnVisData(nodes, edges, d, styles, selected_nodes, filter.connect);

	var network = new vis.Network(document.getElementById(param.div_name), 
			{ nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) }, 
			{layout: {randomSeed: undefined, improvedLayout:false}});
}